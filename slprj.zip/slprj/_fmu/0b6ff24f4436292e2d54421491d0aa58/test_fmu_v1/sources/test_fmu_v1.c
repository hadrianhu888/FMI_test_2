#include "test_fmu_v1_macros.h"
#include "test_fmu_v1.h"

ExtU_test_fmu_v1_T test_fmu_v1_U;
ExtY_test_fmu_v1_T test_fmu_v1_Y;
static RT_MODEL_test_fmu_v1_T test_fmu_v1_M_;
RT_MODEL_test_fmu_v1_T *const test_fmu_v1_M = &test_fmu_v1_M_;
void test_fmu_v1_step(void)
{
  test_fmu_v1_Y.Test_Out = test_fmu_v1_P.Gain_Gain * test_fmu_v1_U.Test_In;
  fmu_LogOutput();
}

void test_fmu_v1_initialize(void)
{
  (void) memset((void *)test_fmu_v1_M, 0,
                sizeof(RT_MODEL_test_fmu_v1_T));
  test_fmu_v1_U.Test_In = 0.0;
  test_fmu_v1_Y.Test_Out = 0.0;
}

void test_fmu_v1_terminate(void)
{
}
