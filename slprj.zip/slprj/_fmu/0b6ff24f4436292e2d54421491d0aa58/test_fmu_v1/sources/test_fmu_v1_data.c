#include "test_fmu_v1_macros.h"
#include "test_fmu_v1.h"

P_test_fmu_v1_T test_fmu_v1_P = {

  10.0
};
