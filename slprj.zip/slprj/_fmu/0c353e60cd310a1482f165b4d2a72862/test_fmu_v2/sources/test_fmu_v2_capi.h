/*
 * test_fmu_v2_capi.h
 *
 * Code generation for model "test_fmu_v2".
 *
 * Model version              : 1.4
 * Simulink Coder version : 9.7 (R2022a) 13-Nov-2021
 * C source code generated on : Sun Aug 14 16:10:14 2022
 *
 * Target selection: grtfmi.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Execution efficiency
 * Validation result: Not run
 */

#ifndef RTW_HEADER_test_fmu_v2_capi_h_
#define RTW_HEADER_test_fmu_v2_capi_h_
#include "test_fmu_v2.h"

extern void test_fmu_v2_InitializeDataMapInfo(void);

#endif                                 /* RTW_HEADER_test_fmu_v2_capi_h_ */

/* EOF: test_fmu_v2_capi.h */
