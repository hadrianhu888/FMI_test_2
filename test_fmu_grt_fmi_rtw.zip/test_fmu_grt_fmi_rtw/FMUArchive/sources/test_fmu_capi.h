/*
 * test_fmu_capi.h
 *
 * Code generation for model "test_fmu".
 *
 * Model version              : 1.1
 * Simulink Coder version : 9.7 (R2022a) 13-Nov-2021
 * C source code generated on : Thu Aug 11 20:00:21 2022
 *
 * Target selection: grtfmi.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Execution efficiency
 * Validation result: Not run
 */

#ifndef RTW_HEADER_test_fmu_capi_h_
#define RTW_HEADER_test_fmu_capi_h_
#include "test_fmu.h"

extern void test_fmu_InitializeDataMapInfo(void);

#endif                                 /* RTW_HEADER_test_fmu_capi_h_ */

/* EOF: test_fmu_capi.h */
