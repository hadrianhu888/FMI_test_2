/*
 * test_fmu_types.h
 *
 * Code generation for model "test_fmu".
 *
 * Model version              : 1.1
 * Simulink Coder version : 9.7 (R2022a) 13-Nov-2021
 * C source code generated on : Thu Aug 11 20:00:21 2022
 *
 * Target selection: grtfmi.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Execution efficiency
 * Validation result: Not run
 */

#ifndef RTW_HEADER_test_fmu_types_h_
#define RTW_HEADER_test_fmu_types_h_

/* Model Code Variants */

/* Parameters (default storage) */
typedef struct P_test_fmu_T_ P_test_fmu_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_test_fmu_T RT_MODEL_test_fmu_T;

#endif                                 /* RTW_HEADER_test_fmu_types_h_ */
