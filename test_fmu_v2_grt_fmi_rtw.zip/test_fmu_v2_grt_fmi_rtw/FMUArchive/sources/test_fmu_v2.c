/*
 * test_fmu_v2.c
 *
 * Code generation for model "test_fmu_v2".
 *
 * Model version              : 1.4
 * Simulink Coder version : 9.7 (R2022a) 13-Nov-2021
 * C source code generated on : Sun Aug 14 16:10:14 2022
 *
 * Target selection: grtfmi.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Execution efficiency
 * Validation result: Not run
 */

#include "test_fmu_v2.h"
#include "test_fmu_v2_capi.h"

/* External inputs (root inport signals with default storage) */
ExtU_test_fmu_v2_T test_fmu_v2_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_test_fmu_v2_T test_fmu_v2_Y;

/* Real-time model */
static RT_MODEL_test_fmu_v2_T test_fmu_v2_M_;
RT_MODEL_test_fmu_v2_T *const test_fmu_v2_M = &test_fmu_v2_M_;

/* Model step function */
void test_fmu_v2_step(void)
{
  /* Outport: '<Root>/Test_Out' incorporates:
   *  Gain: '<S1>/Gain'
   *  Inport: '<Root>/Test_In'
   */
  test_fmu_v2_Y.Test_Out = test_fmu_v2_P.Gain_Gain * test_fmu_v2_U.Test_In;
}

/* Model initialize function */
void test_fmu_v2_initialize(void)
{
  /* Registration code */

  /* initialize real-time model */
  (void) memset((void *)test_fmu_v2_M, 0,
                sizeof(RT_MODEL_test_fmu_v2_T));

  /* external inputs */
  test_fmu_v2_U.Test_In = 0.0;

  /* external outputs */
  test_fmu_v2_Y.Test_Out = 0.0;

  /* Initialize DataMapInfo substructure containing ModelMap for C API */
  test_fmu_v2_InitializeDataMapInfo();
}

/* Model terminate function */
void test_fmu_v2_terminate(void)
{
  /* (no terminate code required) */
}
