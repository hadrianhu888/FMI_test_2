#ifndef RTW_HEADER_test_fmu_v1_types_h_
#define RTW_HEADER_test_fmu_v1_types_h_

typedef struct P_test_fmu_v1_T_ P_test_fmu_v1_T;
typedef struct tag_RTM_test_fmu_v1_T RT_MODEL_test_fmu_v1_T;

#endif
