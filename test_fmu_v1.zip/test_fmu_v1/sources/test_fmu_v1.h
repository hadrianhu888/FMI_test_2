#ifndef RTW_HEADER_test_fmu_v1_h_
#define RTW_HEADER_test_fmu_v1_h_
#ifndef test_fmu_v1_COMMON_INCLUDES_
#define test_fmu_v1_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif

#include "test_fmu_v1_types.h"
#include <string.h>

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

typedef struct {
  real_T Test_In;
} ExtU_test_fmu_v1_T;

typedef struct {
  real_T Test_Out;
} ExtY_test_fmu_v1_T;

struct P_test_fmu_v1_T_ {
  real_T Gain_Gain;
};

struct tag_RTM_test_fmu_v1_T {
  const char_T *errorStatus;
};

extern P_test_fmu_v1_T test_fmu_v1_P;
extern ExtU_test_fmu_v1_T test_fmu_v1_U;
extern ExtY_test_fmu_v1_T test_fmu_v1_Y;
extern void test_fmu_v1_initialize(void);
extern void test_fmu_v1_step(void);
extern void test_fmu_v1_terminate(void);
extern RT_MODEL_test_fmu_v1_T *const test_fmu_v1_M;
extern void fmu_LogOutput();

#endif
