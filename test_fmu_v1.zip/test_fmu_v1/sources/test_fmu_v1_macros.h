/* Define MACROS */
#ifndef MODEL
#define MODEL test_fmu_v1
#endif
#ifndef NUMST
#define NUMST 1
#endif
#ifndef NCSTATES
#define NCSTATES 0
#endif
#ifndef HAVESTDIO
#define HAVESTDIO 
#endif
#ifndef RT
#define RT 
#endif
#ifndef USE_RTMODEL
#define USE_RTMODEL 
#endif
#ifndef CLASSIC_INTERFACE
#define CLASSIC_INTERFACE 0
#endif
#ifndef ALLOCATIONFCN
#define ALLOCATIONFCN 0
#endif
#ifndef TID01EQ
#define TID01EQ 0
#endif
#ifndef MAT_FILE
#define MAT_FILE 0
#endif
#ifndef ONESTEPFCN
#define ONESTEPFCN 1
#endif
#ifndef TERMFCN
#define TERMFCN 1
#endif
#ifndef MULTI_INSTANCE_CODE
#define MULTI_INSTANCE_CODE 0
#endif
#ifndef INTEGER_CODE
#define INTEGER_CODE 0
#endif
#ifndef MT
#define MT 0
#endif